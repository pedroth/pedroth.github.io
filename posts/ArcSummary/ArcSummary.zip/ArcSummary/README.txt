## ArcSummarizer ##

# Setup :
1          - Install ffmpeg.
2          - Change "ffmpeg" parameter with the ffmpeg installation path in conf.txt file (check conf.txt file for an example).
(Optional) - Add or remove words from stopWords.txt to configure stop words list used

#Run :
1 - write on the console/terminal/command line the following :
	
	java -Xmx1024m -classpath "ArcSummary.jar;lib/Jama-1.0.3.jar" nlp.seriesSummary.ArcSummaryServer <port>

2 - Open Browser (works better on Mozilla) at :
	
	localhost:<port>/ArcSummary

(Optional) - click ArcSummary.bat (Windows) or run ArcSummary.sh (Linux)

# Contacts 
	email : pedrotiago92@gmail.com

#Notes:
	Videos are stored in the web folder
	Subtitles must have the same name as the video
	Subtitles must be in the srt format 