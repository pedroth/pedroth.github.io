sensible-browser http://localhost:31415/ArcSummary
echo "http://localhost:31415/ArcSummary"
java -Xmx1024m -classpath ArcSummary.jar:lib/Jama-1.0.3.jar nlp.seriesSummary.ArcSummaryServer "31415" 


