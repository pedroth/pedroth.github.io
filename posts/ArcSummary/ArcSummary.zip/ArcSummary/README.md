# ArcSummarizer

## Setup

1. Install ffmpeg.
2. Change `ffmpeg` parameter with the ffmpeg installation path in `conf.txt` file (check `conf.txt` file for an example).
3. (Optional) - Add or remove words from stopWords.txt to configure stop words list used

## Run

1. Write on the console/terminal/command line the following:
   `java -Xmx1024m -classpath "ArcSummary.jar;lib/Jama-1.0.3.jar" nlp.seriesSummary.ArcSummaryServer <port>`

2. Open Browser (works better on Mozilla) at: `localhost:<port>/ArcSummary`

Or simply:

- Click `ArcSummary.bat` (Windows)
- Run `ArcSummary.sh` (Linux):
  - `sh ArcSummary.sh`

## Running using docker

Just run:

```sh
sudo docker run -it -v <full path to folder where your series are>:<some container folder> -p 31415:31415 pedroth/arc-summary
```

It will run a page at `localhost:31415/ArcSummary`. There you must insert the full path to folder where the series is in the container.

### Example

A simple example would be: 

```sh
sudo docker run -it -v ~/Downloads/OverTheGardenWall:/app/OverTheGardenWall -p 31415:31415 pedroth/arc-summary
```

Then in `localhost:31415/ArcSummary`, in the `base folder` input you should put `/app/OverTheGardenWall`.

# Contacts

- email : `pedrotiago92@gmail.com`

# Notes:

- Videos are stored in the web folder
- Subtitles must have the same name as the video
- Subtitles must be in the srt format
