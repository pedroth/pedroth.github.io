# README

## Requirements

- Install >= Java 8
- Add Java to path [Tutorial here](https://stackoverflow.com/questions/1672281/environment-variables-for-java-installation) (Windows)
  - Just need to add JAVA_HOME and add it to PATH

## Windows

- Click on the run.bat file
- Or open command line and type:
  - `java -cp LinesSurfaces.jar apps.LinesSurfaces`

## Linux

- Open terminal and type:
  - `sh run.sh`
- Or type in the terminal:
  - `java -cp LinesSurfaces.jar apps.LinesSurfaces`

## Docker

- Run: `sh runDocker.sh`
