java -cp BrownianMotion.jar apps.BrownianMotion
