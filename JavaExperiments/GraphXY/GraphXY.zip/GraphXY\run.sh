java -cp GraphXY.jar apps.GraphXY
