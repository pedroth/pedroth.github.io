it runs faster if you click on run.bat, or simply click on the jar application

if you are on windows in order to run it you must have java
on the console/comand line