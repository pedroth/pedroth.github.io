java -cp ImplicitSurface.jar apps.src.ImplicitSurface
