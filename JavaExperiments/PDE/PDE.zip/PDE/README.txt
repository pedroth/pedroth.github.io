it runs faster if you click on run.bat

if you are on windows in order to run it you must have java
on the console/comand line