java -cp PDE.jar apps.PDEGUI
