java -cp CellularAutomaton.jar apps.ParallelCellularAutomaton
