java -cp CubeChaos.jar apps.Cube
