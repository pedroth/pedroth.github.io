java -cp RandomCurve.jar apps.RandomCurve
