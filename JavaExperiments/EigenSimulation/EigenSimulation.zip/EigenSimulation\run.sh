java -cp EigenSimulation.jar apps.src.EigenSimulation
