In order to run the application, press the .jar file.

If that doens't work open a command line and run : java -jar <App Name>.jar

If you have java in the path variable just run the .bat/.sh file