java -cp SimplePhysics.jar apps.SimplePhysics
