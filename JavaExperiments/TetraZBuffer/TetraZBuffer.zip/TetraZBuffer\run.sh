java -cp TetraZBuffer.jar apps.Tetra
