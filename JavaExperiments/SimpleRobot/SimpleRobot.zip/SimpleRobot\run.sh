java -cp SimpleRobot.jar apps.Robot
